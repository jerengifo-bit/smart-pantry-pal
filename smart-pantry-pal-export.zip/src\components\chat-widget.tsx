import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { generateChatResponse, type ChatMessage } from "../lib/mock-chat-engine";
import { usePantry } from "../lib/pantry-store";
import { Card, CardContent } from "./ui/card";
import { Clock, Users } from "lucide-react";

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "agent",
      content: "¡Hola! Soy tu asistente de cocina. Dime qué tienes en tu despensa o qué se te antoja comer y te ayudaré a encontrar algo rápido y delicioso."
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { pantry } = usePantry();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
    };

    const currentMessages = [...messages, userMessage];
    setMessages(currentMessages);
    setInput("");
    setIsTyping(true);

    try {
      const pantryNames = pantry.map(item => item.name);
      const response = await fetch("https://jerengifo.app.n8n.cloud/webhook/Cocinawh", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: userMessage.content,
          history: messages,
          pantry: pantryNames
        })
      });

      if (!response.ok) throw new Error("Network response was not ok");
      
      const data = await response.json();
      
      const responseContent = data.responseText || data.output || data.text || data.message || data.response || (typeof data === 'string' ? data : JSON.stringify(data));
      
      const agentMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "agent",
        content: responseContent,
        recipes: data.suggestedRecipes || [],
      };
      
      setMessages((prev) => [...prev, agentMessage]);
    } catch (error) {
      console.error("Error calling n8n webhook:", error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: "agent",
        content: "Ocurrió un error al conectar con el asistente. Por favor intenta de nuevo.",
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <div className="fixed bottom-6 right-6 z-50 md:bottom-10 md:right-10">
        {!isOpen && (
          <Button
            onClick={() => setIsOpen(true)}
            className="h-14 w-14 rounded-full shadow-xl transition-transform hover:scale-105 active:scale-95 bg-primary text-primary-foreground"
            size="icon"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        )}
      </div>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 z-50 flex h-[85vh] w-full flex-col overflow-hidden rounded-t-2xl border bg-background shadow-2xl sm:bottom-6 sm:right-6 sm:h-[600px] sm:w-[400px] sm:rounded-2xl">
          {/* Header */}
          <div className="flex items-center justify-between border-b bg-primary p-4 text-primary-foreground">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-sm">Chef Asistente</h3>
                <p className="text-xs text-primary-foreground/80">En línea</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="text-primary-foreground hover:bg-primary-foreground/20 rounded-full h-8 w-8"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 bg-muted/30">
            <div className="flex flex-col gap-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div className={`flex max-w-[85%] flex-col gap-2 ${msg.role === "user" ? "items-end" : "items-start"}`}>
                    <div
                      className={`rounded-2xl px-4 py-2 text-sm ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground rounded-tr-sm"
                          : "bg-white border text-foreground rounded-tl-sm shadow-sm"
                      }`}
                    >
                      {msg.content}
                    </div>
                    
                    {/* Recipes Cards inside chat */}
                    {msg.recipes && msg.recipes.length > 0 && (
                      <div className="flex flex-col gap-2 w-full mt-1">
                        {msg.recipes.map((recipe) => (
                          <Card key={recipe.id} className="overflow-hidden shadow-sm border-muted transition-all hover:border-primary/50">
                            <div className="flex h-20 w-full overflow-hidden">
                              <img src={recipe.image} alt={recipe.name} className="w-1/3 object-cover" />
                              <div className="flex w-2/3 flex-col justify-center p-3">
                                <h4 className="font-semibold text-sm line-clamp-1">{recipe.name}</h4>
                                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                                  <div className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    <span>{recipe.minutes}m</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Users className="h-3 w-3" />
                                    <span>{recipe.servings}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="bg-muted/30 p-2 text-center">
                              <a href={`/recetas?id=${recipe.id}`} className="text-xs font-medium text-primary hover:underline block w-full">
                                Ver detalle de la receta
                              </a>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex max-w-[85%] flex-col gap-2 items-start">
                    <div className="rounded-2xl px-4 py-3 text-sm bg-white border text-foreground rounded-tl-sm shadow-sm flex items-center gap-1.5 h-10">
                      <div className="w-1.5 h-1.5 bg-muted-foreground/60 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-muted-foreground/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-1.5 h-1.5 bg-muted-foreground/60 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Input Area */}
          <div className="border-t bg-background p-4">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <Input
                placeholder="Ej. Tengo pollo y arroz..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 rounded-full bg-muted/50 focus-visible:ring-primary/20"
              />
              <Button
                type="submit"
                size="icon"
                disabled={!input.trim()}
                className="rounded-full h-10 w-10 shrink-0"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

import { peruvianRecipes } from "./peruvian-recipes";
import type { Recipe } from "./pantry-types";

export interface ChatMessage {
  id: string;
  role: "user" | "agent";
  content: string;
  recipes?: Recipe[];
}

export function generateChatResponse(
  input: string,
  history: ChatMessage[],
  pantryItems: string[] = []
): { responseText: string; suggestedRecipes?: Recipe[] } {
  const lowerInput = input.toLowerCase();

  if (lowerInput.includes("cansad") || lowerInput.includes("rápid") || lowerInput.includes("noche") || lowerInput.includes("agotad")) {
    const fastRecipes = peruvianRecipes.filter((r) => r.minutes <= 25).slice(0, 2);
    return {
      responseText: "Veo que estás cansado. Tienes lo necesario para algo rápido. Te toma máximo 25 minutos hacer alguna de estas opciones. ¿Te guío?",
      suggestedRecipes: fastRecipes,
    };
  }

  if (lowerInput.includes("pescado") || lowerInput.includes("marisco") || lowerInput.includes("ceviche")) {
    const fishRecipes = peruvianRecipes
      .filter((r) => r.main.some((i) => i.toLowerCase().includes("pescado") || i.toLowerCase().includes("marisco") || i.toLowerCase().includes("camarón")))
      .slice(0, 2);
    return {
      responseText: "¡Perfecto! El pescado es una gran opción. Aquí tienes un par de ideas:",
      suggestedRecipes: fishRecipes,
    };
  }

  if (lowerInput.includes("pollo") || lowerInput.includes("gallina")) {
    const chickenRecipes = peruvianRecipes
      .filter((r) => r.main.some((i) => i.toLowerCase().includes("pollo") || i.toLowerCase().includes("gallina")))
      .slice(0, 2);
    return {
      responseText: "Pollo es un clásico. Basado en tus preferencias, estas opciones siempre quedan bien:",
      suggestedRecipes: chickenRecipes,
    };
  }
  
  if (lowerInput.includes("barato") || lowerInput.includes("económico")) {
      const cheapRecipes = peruvianRecipes.filter((r) => r.main.some(i => i.toLowerCase().includes("papa") || i.toLowerCase().includes("frijol"))).slice(0,2);
      const fallback = peruvianRecipes.filter(r => r.id === "pe4" || r.id === "pe9");
      return {
          responseText: "¡Entendido! Cuidemos el bolsillo. Estas recetas llevan ingredientes muy accesibles y llenan bastante:",
          suggestedRecipes: cheapRecipes.length > 0 ? cheapRecipes : fallback
      }
  }

  const hasComma = lowerInput.includes(",");
  const hasY = lowerInput.includes(" y ");
  if (hasComma || hasY || lowerInput.includes("tengo") || lowerInput.includes("hay")) {
    const dynamicRecipe: Recipe = {
      id: "dynamic-1",
      name: "Arroz Frito de Supervivencia",
      meal: "almuerzo",
      minutes: 15,
      image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=400",
      servings: 1,
      main: ["Ingredientes que mencionaste", "Arroz de ayer"],
      basics: ["Aceite", "Sal", "Sillao"],
      steps: [
        "Calienta un poco de aceite en la sartén a fuego alto.",
        "Fríe un huevo rápidamente y rómpelo en pedazos.",
        "Agrega los restos que mencionaste y saltea todo junto.",
        "Echa un chorrito de sillao al final para darle color y sabor."
      ]
    };
    return {
      responseText: "¡Excelente! No desperdiciemos nada. Con esos ingredientes no necesitas seguir una receta clásica. Te propongo este invento rápido:",
      suggestedRecipes: [dynamicRecipe]
    };
  }

  const randomRecipes = [...peruvianRecipes].sort(() => 0.5 - Math.random()).slice(0, 2);
  return {
    responseText: "¡Suena bien! Te sugiero un par de platos deliciosos que creo que te van a encantar. ¿Qué te parecen?",
    suggestedRecipes: randomRecipes,
  };
}
